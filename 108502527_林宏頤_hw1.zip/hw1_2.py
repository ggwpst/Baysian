import random
import matplotlib.pyplot as plt


def estimate_pi(total_points):
    points_inside_circle = 0

    for i in range(total_points):
        x = random.uniform(0, 1)
        y = random.uniform(0, 1)

        if (x-0.5)**2 + (y-0.5)**2 < 0.25:
            points_inside_circle += 1

    pi_estimate = 4 * points_inside_circle / total_points
    return pi_estimate


x_values = []
y_values = []

for i in range(2, 6):
    total_points = 10 ** i
    pi_estimate = estimate_pi(total_points)

    x_values.append(i)
    y_values.append(pi_estimate)

plt.plot(x_values, y_values)
plt.xlabel('log(total points)')
plt.ylabel('Estimated value of pi')
plt.show()
